import React from 'react'
import Foooter from '../components/Foooter'
import Homeee from '../components/Homeee'
import View from '../components/View'
import Category from '../components/Category'

function Homee() {
  return (
   <div>
      <div><Homeee/></div>
      <div className='d-flex justify-content-between mb-5 '>
        <View/>
     <Category/>
      </div>
   </div>
  )
 
}

<Foooter/>
export default Homee