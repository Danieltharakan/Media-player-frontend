import React from 'react'
import { Modal } from 'react-bootstrap'
import { Form } from 'react-bootstrap'
import { useState } from 'react';
import Button from 'react-bootstrap/Button';

function Category() {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
 
  return (
    <>
    <div>
        <button onClick={handleShow} style={{backgroundColor:"orange",color:"white",borderRadius:"10px",width:"200px",height:"50px"}}>Add new category</button>
    </div>
    <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Add New Category Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
         <form  className='border borderr-secondary p-3 rounded'>
          
  <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Control type="text" placeholder="Enter Category ID" />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Control type="text" placeholder="Enter Vedio Caption" />
      </Form.Group>

     

         </form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary">ADD</Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default Category