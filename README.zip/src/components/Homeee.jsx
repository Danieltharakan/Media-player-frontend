import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { Form } from 'react-bootstrap';

function Homeee() {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    < >
      <div className="d-flex upload-container container justify-content-between">
            <div className='d-flex gap-2'>
              <h5><i style={{color:"orange"}} class="fa-solid fa-film"></i>Upload video</h5>
              <button onClick={handleShow} style={{background:'transparent',border:'none'}}><i class="fa-solid fa-cloud-arrow-up fa-2x" style={{color:'gold'}}></i></button>
            </div>
            <div className=''>
              <Link style={{textDecoration:'none',color:'white'}} to={'/watch-history'}> <h5>Watch History</h5></Link>
            </div>
      </div>
      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Modal title</Modal.Title>
        </Modal.Header>
        <Modal.Body>
         <form  className='border borderr-secondary p-3 rounded'>
          
  <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Control type="text" placeholder="Enter Vedio ID" />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Control type="text" placeholder="Enter Vedio Caption" />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Control type="text" placeholder="Enter vedio image Url" /> 
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Control type="text" placeholder="Enter Youtube Vedio LInk" />
      </Form.Group>

         </form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary">Understood</Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default  Homeee
