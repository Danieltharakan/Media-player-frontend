import React from 'react'
import { Card } from 'react-bootstrap'
function Vediocard() {
  return (
    <div>
              <Card style={{ width: '22rem' }}>
          <Card.Img variant="top" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg8DVULO_RJgGl899mQNT-c5KDJb7bXWNPfPDKSMUNwyEm4TxUllz7vZlocuuDAkG9BhT8BR8urIgXMrBX8Q2kWihJDC6gURJrnt8kRwqr8Zy9-yN8NdTtwokE2t7WUsjwbNvaf-PqBp8Dre6-wX7lNhT-5Iv-G6d4SgcM7PVXNVW9L1y2KVY6SiAFH/s640/ab67616d0000b273180104e7be9951df3303616f.jpg" />
       
              <Card.Body>
             <Card.Title className='d-flex justify-content-between align-items-center'>
                    <Card.Title>Video Caption</Card.Title>
                
                  <button style={{backgroundColor:"transparent" , border:"none", color:"red"}}>  <i class="fa-solid fa-trash "></i></button>
                    
                  </Card.Title>
                  <p style={{fontSize:"small"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque maiores dignissimos consequatur odit velit officia consequuntur </p>
                
              </Card.Body>
       
        </Card>
    </div>
  )
}

export default Vediocard