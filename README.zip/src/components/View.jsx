import React from 'react'

import Vediocard from './Vediocard'
import { Row,Col } from 'react-bootstrap'


function View() {
  return (
    <div>
       <Row>
        
          <Col sm={12} md={6} lg={4} xl={3}>
            <Vediocard/>
          </Col>
         {/*   
          <Col sm={12} md={6} lg={4} xl={3}>
            <Vediocard/>
          </Col>
           
          <Col sm={12} md={6} lg={4} xl={3}>
            <Vediocard/>
          </Col>
           
          <Col sm={12} md={6} lg={4} xl={3}>
            <Vediocard/>
          </Col>
           
          <Col sm={12} md={6} lg={4} xl={3}>
            <Vediocard/>
          </Col> */}
        
       </Row>
        
        </div> 
  )
}

export default View